
#include <stdio.h>
//声明要调用库中的函数
int add(int a,int b);

int main()
{
	printf("%d\n",add(1,7));
	return 0;
}
