
#include "hello.h"
#include "stdio.h"

int add(int a, int b);
int main()
{
	hello();
        printf("%d\n",add(1,2));
	return 0;
}
