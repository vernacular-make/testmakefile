#ifdef _HELLO_H_
#define _HELLO_H_
 
void hello();
 
#endif
