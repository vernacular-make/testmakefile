// fun.cpp

#include "Fun.h"

void fun()
{
    std::cout << "Hello World !" << std::endl;
}
