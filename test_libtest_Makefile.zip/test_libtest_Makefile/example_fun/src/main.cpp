// main.cpp

#include "Fun.h"
int main()
{
    fun();
    return 0;
}
