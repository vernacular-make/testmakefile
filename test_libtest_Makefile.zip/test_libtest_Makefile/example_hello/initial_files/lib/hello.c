#include "hello.h"
#include <stdio.h>
void hello()
{
	printf("hello world!\n");
}
