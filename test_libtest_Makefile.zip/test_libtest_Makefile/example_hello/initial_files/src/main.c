
#include "hello.h"
int main()
{
	hello();
}
