#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include <isa-l.h>
#include <timing.h>

#define TEST_SOURCES 16
#define TEST_LEN     1024
#define TEST_MEM ((TEST_SOURCES + 1)*(TEST_LEN))
#ifndef TEST_SEED
# define TEST_SEED 0x1234
#endif

void rand_buffer(unsigned char *buf, long buffer_size)
{
	long i;
	for (i = 0; i < buffer_size; i++)
		buf[i] = rand();
}

void number_buffer(unsigned int *buf, int buffer_size)
{
	int i;
	for (i = 0; i < buffer_size; i++)
		buf[i] = rand()%400;
}

int main(int argc, char *argv[])
{
        int test=1;
	int i, j, k, ret, ret1, fail = 0;
	void *buffs[TEST_SOURCES + 1];
        void *buffs_test[4+1];//
	char *tmp_buf[TEST_SOURCES + 1];

	printf("Test xor_gen_test ");

	srand(TEST_SEED);
         
        /* Timing variables */
	struct timing t1, t2;
	double totalsec;
	//struct timing start;

        /* Start timing */
	totalsec = 0.0;

	// Allocate the arrays
	for (i = 0; i < TEST_SOURCES + 1; i++) {
		void *buf;
		ret = posix_memalign(&buf, 32, TEST_LEN);
		if (ret) {
			printf("alloc error: Fail");
			return 1;
		}
		buffs[i] = buf;
	}

        //Own arrays  (5*5:  4*5 get 1*5)  src元数据前TEST_SOURCES（4）列元素（每列数据5个元素） 异或 得到的结果存在最后一列（第5列）整体存在一个arrays中
        //调用posix_memalign( )成功时会返回size字节的动态内存，并且这块内存的地址是alignment的倍数。参数alignment必须是2的幂，还是void指针的大小的倍数。返回的内存块的地址放在了memptr里面，函数返回值是0.
	for (i = 0; i <4 + 1; i++) {
		void *buf1;
		ret1 = posix_memalign(&buf1, 32, 5);
		if (ret1) {
			printf("alloc error: Fail");
			return 1;
		}
		buffs_test[i] = buf1;
	}          

	// Test of all zeros
        printf("Zero_before xor\n");
	for (i = 0; i < TEST_SOURCES + 1; i++){
		memset(buffs[i], 0, TEST_LEN);
                printf("%d*",((int *)buffs[i])[0]);//
        }

	test=xor_gen(TEST_SOURCES + 1, TEST_LEN, buffs);//
        printf("%d\n",test);//
      
        printf("Zero_after xor\n");
        for (i = 0; i < TEST_SOURCES + 1; i++){
                printf("%d*",((int *)buffs[i])[0]);
        }//
         
        printf("begin.\n");//         
	for (i = 0; i < TEST_LEN; i++) {
		if (((char *)buffs[TEST_SOURCES])[i] != 0)
			fail++;
	}

	if (fail > 0) {
		printf("fail zero test");
		return 1;
	} else
		putchar('.');

	// Test rand1
        printf("rand1_before xor\n");
	for (i = 0; i < TEST_SOURCES + 1; i++){
		rand_buffer(buffs[i], TEST_LEN);
                printf("%d*",((int *)buffs[i])[0]);//
        }
     
	test=xor_gen(TEST_SOURCES + 1, TEST_LEN, buffs);
        printf("%d\n",test);//
      
        printf("rand1_after xor\n");//
        for (i = 0; i < TEST_SOURCES + 1; i++){
                printf("%d*",((int *)buffs[i])[0]);
        }//
         
        printf("begin.\n");// 
	fail |= xor_check_base(TEST_SOURCES + 1, TEST_LEN, buffs);

	if (fail > 0) {
		printf("fail rand test %d\n", fail);
		return 1;
	} else
		putchar('.');


        /*Test sepecific Numbers*/
        /*3 6 8 9 6
          3 6 8 9 4
          (3^6^8^9=4)*/
        printf("sepecific_before xor\n");
	for (i = 0; i < 5; i++){
                number_buffer(buffs_test[i], 5);
                printf("%d*",((int *)buffs_test[i])[0]);
        }

        timing_set(&t1);
        test=xor_gen(5, 5, buffs_test);
        //timing_set(&start);
	timing_set(&t2);
	totalsec += timing_delta(&t1, &t2);
        printf("xor_gen(MB/sec): %0.10f\n", (((double) 4*5)/1024.0/1024.0)/totalsec);

        printf("%d\n",test);
     
        printf("sepecific_after xor\n");
        for (i = 0; i < 5; i++){
           printf("%d*",((int *)buffs_test[i])[0]);
        } 
     
        printf("normal:%d",3^6^8^9);
       
	// Test various number of sources
	for (j = 3; j <= TEST_SOURCES + 1; j++) {
		for (i = 0; i < j; i++)
			rand_buffer(buffs[i], TEST_LEN);

		xor_gen(j, TEST_LEN, buffs);
		fail |= xor_check_base(j, TEST_LEN, buffs);

		if (fail > 0) {
			printf("fail rand test %d sources\n", j);
			return 1;
		} else
			putchar('.');
	}

	fflush(0);

	// Test various number of sources and len
	k = 0;
	while (k <= TEST_LEN) {
		for (j = 3; j <= TEST_SOURCES + 1; j++) {
			for (i = 0; i < j; i++)
				rand_buffer(buffs[i], k);

			xor_gen(j, k, buffs);
			fail |= xor_check_base(j, k, buffs);

			if (fail > 0) {
				printf("fail rand test %d sources, len=%d, ret=%d\n", j, k,
				       fail);
				return 1;
			}
		}
		putchar('.');
		k += 1;
	}

	// Test at the end of buffer
	for (i = 0; i < TEST_LEN; i += 32) {
		for (j = 0; j < TEST_SOURCES + 1; j++) {
			rand_buffer((unsigned char *)buffs[j] + i, TEST_LEN - i);
			tmp_buf[j] = (char *)buffs[j] + i;
		}

		xor_gen(TEST_SOURCES + 1, TEST_LEN - i, (void *)tmp_buf);
		fail |= xor_check_base(TEST_SOURCES + 1, TEST_LEN - i, (void *)tmp_buf);

		if (fail > 0) {
			printf("fail end test - offset: %d, len: %d\n", i, TEST_LEN - i);
			return 1;
		}

		putchar('.');
		fflush(0);
	}

	if (!fail)
		printf(" done: Pass\n");

	return fail;
}
