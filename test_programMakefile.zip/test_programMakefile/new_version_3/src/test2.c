#include<stdio.h>
#include<stdint.h>
#include<string.h>
#include<stdlib.h>
#include <isa-l.h>
#include <timing.h>
typedef unsigned char u8;
void number_buffer(unsigned char *buf, int  buffer_size)
{
	int i;
	for (i = 0; i < buffer_size; i++)
		buf[i] = rand()%1000;
}


int main(int argc, char *argv[])
{
        int test=0;
        void *buffs_test[4+1];
        u8 gftbl[64], d = 3;
        unsigned char *buffs_src;     //64
        unsigned char *buffs_dec;     //64

	int i, j, k, ret, ret1, fail = 0;        
        unsigned char a=10;
        unsigned char b=221;
        unsigned char c;

        printf("Test gf_mul:");
        c=gf_mul(a,b);
        //c=gf_inv(a);
        printf("%d\n",c);

        //test-------int xor_gen(int vects, int len, void **array);
        //open the space      
        buffs_src=(unsigned char*)malloc(64);
        buffs_dec=(unsigned char*)malloc(64);

        printf("%u__\n",gftbl[0]);
        printf("%u__\n",buffs_src[0]);
        
        for (i = 0; i <4 + 1; i++) {
		void *buf1;
		ret1 = posix_memalign(&buf1, 32, 5);//
		if (ret1) {
			printf("alloc error: Fail");
			return 1;
		}
		buffs_test[i] = buf1;
	}

        printf("sepecific_before xor\n");
        
        //printf("%u__\n",((unsigned int *)buffs_test[1])[1]);
	for (i = 0; i < 5; i++){
                number_buffer(buffs_test[i], 5);
                printf("%u*",((unsigned char *)buffs_test[i])[0]);
        }
             

        test=xor_gen(5, 5, buffs_test);//
        printf("\ntest=%d\n",test);//


        printf("sepecific_after xor\n");
        for (i = 0; i < 5; i++){
           printf("%d_",((unsigned char *)buffs_test[i])[0]);
        } 
        printf("\n");
       
        ////////////////////////////////
        //test----int gf_vect_mul(int len, unsigned char *gftbl, void *src, void *dest);
        printf("sepecific_before mul\n");
        gf_vect_mul_init(d, gftbl);
        number_buffer(buffs_src,64);
        number_buffer(buffs_dec,64);
	
       
        

        for (i = 0; i < 10; i++){
                printf("%d*",gftbl[i]);
        }
        printf("\n");

        for (i = 0; i < 5; i++){
            printf("%d_",buffs_src[i]);

        }
        printf("\n");
       
       
       test=0;
       //gf_vect_mul_base(64, gftbl, buffs_src, buffs_dec);
       test=gf_vect_mul(64, gftbl, buffs_src, buffs_dec);
       printf("test:%d\n",test);
       
       printf("sepecific_after_mul\n");
       for (i = 0; i < 4; i++){
           printf("%u_",buffs_dec[i]);
       } 
       printf("\n");    
       
}








